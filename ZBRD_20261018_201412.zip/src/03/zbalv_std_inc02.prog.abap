*************************************************************************
* 이 프로그램은 저작권 법에 따라 보호받는 BR Developer Group의 지적 재산으로서,
* 무단 사용, 무단 복제하는 행위는 금지되어 있으며 법적제재를 받을 수 있습니다.
* 한국 저작권 위원회 등록번호 : C-2018-000076
* Copyright 2018 BR Developer Group All right reserved.
* http://www.brdev.co.kr:8080/flp
* bradryu@hotmail.com
*************************************************************************
*************************************************************************
* Modules / Sub Module : CM / Z
*&---------------------------------------------------------------------
* T_CODE             : ZBALV_STD_INC02
* WRITER             : BRAD.RYU
* DATE               : 2015.12.10
* TYPE               : Include Report
* Description        : 공통 sub routine, define include프로그램
*
*************************************************************************
*              Changed History
*&---------------------------------------------------------------------**
*Changed Number     Changed Date   Writer    Changed      Description
*&---------------------------------------------------------------------**
*      N            2015.12.10    BRAD.RYU   CREATE       CREATE       *
*************************************************************************

DEFINE _set_timestamp_create.
  CLEAR gs_create_timestamp.
  gs_create_timestamp-ernam = sy-uname.
  gs_create_timestamp-erdat = sy-datum.
  gs_create_timestamp-erzet = sy-uzeit.
  gs_create_timestamp-aenam = sy-uname.
  gs_create_timestamp-aedat = sy-datum.
  gs_create_timestamp-aezet = sy-uzeit.
  MOVE-CORRESPONDING gs_create_timestamp TO &1.
END-OF-DEFINITION.
DEFINE _set_timestamp_change.
  CLEAR gs_change_timestamp.
  gs_change_timestamp-aenam = sy-uname.
  gs_change_timestamp-aedat = sy-datum.
  gs_change_timestamp-aezet = sy-uzeit.
  MOVE-CORRESPONDING gs_change_timestamp TO &1.
END-OF-DEFINITION.
DEFINE _set_local_timestamp_create.
  &1-ernam = sy-uname.
  &1-erdat = sy-datlo.
  &1-erzet = sy-timlo.
  &1-aenam = sy-uname.
  &1-aedat = sy-datlo.
  &1-aezet = sy-timlo.
END-OF-DEFINITION.
DEFINE _set_local_timestamp_change.
  &1-aenam = sy-uname.
  &1-aedat = sy-datlo.
  &1-aezet = sy-timlo.
END-OF-DEFINITION.
DEFINE _set_toolbar.
  CLEAR &1.
  MOVE &2 TO &1-butn_type.
  MOVE &3 TO &1-function.
  MOVE &4 TO &1-icon.
  MOVE &5 TO &1-quickinfo.
  MOVE &6 TO &1-text.
  MOVE &7 TO &1-disabled.

END-OF-DEFINITION.
DEFINE _set_alv_cell.
  po_object->modify_cell(
    EXPORTING
      i_row_id    = &1
      i_fieldname = &2
      i_value     = &3 ).
END-OF-DEFINITION.
DEFINE _remove_comma.
  _remove_char &1 ','.
END-OF-DEFINITION.
DEFINE _remove_period.
  _remove_char &1 '.'.
END-OF-DEFINITION.
DEFINE _remove_char.
  REPLACE ALL OCCURRENCES OF &2 IN &1 WITH ''.
END-OF-DEFINITION.
DEFINE _set_range.
  CLEAR &1.
  &1-sign = &2.
  &1-option = &3.
  &1-low = &4.
  &1-high = &5.
  APPEND &1.
END-OF-DEFINITION.
DEFINE _set_eq_range.
  CLEAR &1.
  &1-sign = 'I'.
  &1-option = 'EQ'.
  &1-low = &2.
  IF &3 NE ''.
  &1-high = &3.
  ENDIF.
  APPEND &1.
END-OF-DEFINITION.
DEFINE _set_bt_range.
  CLEAR &1.
  &1-sign = 'I'.
  &1-option = 'BT'.
  &1-low = &2.
  IF &3 NE ''.
  &1-high = &3.
  ENDIF.
  APPEND &1.
END-OF-DEFINITION.
DEFINE _set_cp_range.
  CLEAR &1.
  &1-sign = 'I'.
  &1-option = 'CP'.
  &1-low = &2.
  IF &3 NE ''.
  &1-high = &3.
  ENDIF.
  APPEND &1.
END-OF-DEFINITION.
DEFINE _set_range_from_param.
  IF &1 IS NOT INITIAL.
    FIND '*' IN &1.
    IF sy-subrc EQ 0.
      _set_cp_range &2 &1 ''.
    ELSE.
      _set_eq_range &2 &1 ''.
  ENDIF.
ENDIF.
END-OF-DEFINITION.
DEFINE _set_last_day_range.
  &1-sign = 'I'.
  &1-option = 'BT'.
   CALL FUNCTION 'LAST_DAY_OF_MONTHS'
     EXPORTING
       day_in            = &1-low
     IMPORTING
       last_day_of_month = &1-high
     EXCEPTIONS
       day_in_no_date    = 1
       OTHERS            = 2.
  APPEND &1.
END-OF-DEFINITION.
DEFINE _clear.
  CLEAR : &1, &1[].
END-OF-DEFINITION.

DEFINE _set_date_format.
  CLEAR gv_date_format.
  gv_date_format = &1(4) && '.' && &1+4(2) && '.' && &1+6(2).
END-OF-DEFINITION.
DEFINE _set_time_format.
  CLEAR gv_time_format.
  gv_time_format = &1(2) && '.' && &1+2(2) && '.' && &1+4(2).
END-OF-DEFINITION.
DEFINE _set_number_format.
  CLEAR gv_number_format.

  CALL FUNCTION 'HRCM_AMOUNT_TO_STRING_CONVERT'
    EXPORTING
      betrg                   = &1
      new_decimal_separator   = '.'
      new_thousands_separator = ','
    IMPORTING
      string                  = &2.
  CONDENSE &2 NO-GAPS.
END-OF-DEFINITION.

*&---------------------------------------------------------------------*
*&      Form  ADD_FILE_OPEN_DIALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_PA_FILE  text
*----------------------------------------------------------------------*
FORM add_excel_file_open_dialog  USING    pv_file.

  DATA: lt_file TYPE filetable,
        ls_file LIKE LINE OF lt_file,
        lv_rc   TYPE i.
  CLEAR : pv_file.

  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      window_title      = 'Select Excel File'
      file_filter       = 'Excel files (*.XLSX)|*.XLSX| Excel files (*.XLS)|*.XLS|'
      default_extension = 'xlsx'
    CHANGING
      file_table        = lt_file
      rc                = lv_rc.

  IF  sy-subrc EQ 0.
    READ TABLE lt_file INTO ls_file INDEX 1.
    MOVE  ls_file-filename   TO  pv_file.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SMW0_FILE_DOWNLOAD
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_0027   text
*      -->P_0028   text
*      -->P_0029   text
*----------------------------------------------------------------------*
FORM smw0_file_download  USING  pv_filename pv_fileid pv_ext   .


  DATA : lv_path TYPE string.
  DATA : ls_item         TYPE wwwdatatab,
         lv_file         TYPE localfile,
         lv_destinamtion TYPE localfile,
         lv_ext          TYPE string,
         lv_filename     TYPE string.
  DATA : rc TYPE i.
  DATA : lv_fullpath TYPE string,
         lv_result   TYPE i.

  TRY.

      lv_ext = pv_ext.
      lv_filename = pv_filename.
      lv_file = pv_fileid.
      IF lv_ext IS INITIAL.
        lv_ext = 'xls'.
      ENDIF.


      SELECT SINGLE relid objid srtf2 checkout checknew
        chname tdate ttime text clustr clustd
      FROM wwwdata
      INTO CORRESPONDING FIELDS OF ls_item
      WHERE objid = lv_file.

      IF ls_item-relid IS INITIAL.
        MESSAGE 'No File Found' TYPE 'I' DISPLAY LIKE 'E'.
        EXIT.
      ENDIF.

      IF lv_filename IS INITIAL.
        lv_filename = ls_item-text.
      ENDIF.

      CALL METHOD cl_gui_frontend_services=>file_save_dialog
        EXPORTING
          default_extension = lv_ext
          default_file_name = lv_filename
          initial_directory = 'C:\'
        CHANGING
          filename          = lv_filename
          path              = lv_path
          fullpath          = lv_fullpath
          user_action       = lv_result.

      IF  sy-subrc EQ 0.
        lv_destinamtion  = lv_fullpath.
      ENDIF.

      CALL FUNCTION 'WS_FILE_DELETE'
        EXPORTING
*         FILE   = LV_FILE
          file   = lv_destinamtion
        IMPORTING
          return = rc.


      CALL FUNCTION 'DOWNLOAD_WEB_OBJECT'
        EXPORTING
          key         = ls_item
          destination = lv_destinamtion
        CHANGING
          temp        = lv_file.

  ENDTRY.
  IF sy-subrc NE 0.
    MESSAGE 'No File Found' TYPE 'I' DISPLAY LIKE 'E'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  itab_to_excel_download
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->
*----------------------------------------------------------------------*
FORM itab_to_excel_download TABLES pt_tab pt_head USING pv_filename pv_path .

  TYPES : BEGIN OF lty_header,
            fieldname TYPE fieldname,
          END OF lty_header.

  DATA: lo_gui    TYPE REF TO cl_gui_frontend_services,
        lv_title  TYPE string,
        lv_folder TYPE string,
        lv_dir    TYPE string.

  DATA lo_table_descr TYPE REF TO cl_abap_tabledescr.
  DATA lo_struct_descr TYPE REF TO cl_abap_structdescr.
  DATA lt_columns TYPE abap_compdescr_tab.
  FIELD-SYMBOLS <ls_column> LIKE LINE OF lt_columns.
  DATA : lt_head TYPE TABLE OF lty_header,
         ls_head TYPE lty_header,
         lv_head TYPE string.
  DATA : lv_filename TYPE string.
**  1. FILE NAME
  IF pv_filename IS INITIAL.
    lv_filename = 'SAMPLE.XLS'.
  ELSE.
    CONCATENATE pv_filename '.XLS'  INTO lv_filename.
  ENDIF.

** 2. HEADER

  lo_table_descr ?= cl_abap_typedescr=>describe_by_data( pt_tab[] ).
  lo_struct_descr ?= lo_table_descr->get_table_line_type( ).
  lt_columns = lo_struct_descr->components.

  IF pt_head[] IS INITIAL.
    LOOP AT lt_columns ASSIGNING <ls_column>.
      CLEAR  ls_head.
      ls_head = <ls_column>-name.
      APPEND ls_head TO lt_head.
    ENDLOOP.
  ELSE.
    LOOP AT pt_head INTO lv_head.
      APPEND lv_head TO lt_head.
    ENDLOOP.
  ENDIF.

  IF pv_path IS INITIAL.
    PERFORM get_file_save_dialog USING lv_filename lv_dir '' ''.
  ELSE.
    lv_dir = pv_path.
  ENDIF.
  IF lv_dir IS INITIAL.
    MESSAGE 'Operation Cancled.' TYPE 'I'.
  ELSE.

    CALL FUNCTION 'GUI_DOWNLOAD'
      EXPORTING
        filename                = lv_dir
        filetype                = 'ASC'
        write_field_separator   = 'X'
      TABLES
        data_tab                = pt_tab
        fieldnames              = lt_head
      EXCEPTIONS
        file_write_error        = 1
        no_batch                = 2
        gui_refuse_filetransfer = 3
        invalid_type            = 4
        no_authority            = 5
        unknown_error           = 6
        header_not_allowed      = 7
        separator_not_allowed   = 8
        filesize_not_allowed    = 9
        header_too_long         = 10
        dp_error_create         = 11
        dp_error_send           = 12
        dp_error_write          = 13
        unknown_dp_error        = 14
        access_denied           = 15
        dp_out_of_memory        = 16
        disk_full               = 17
        dp_timeout              = 18
        file_not_found          = 19
        dataprovider_exception  = 20
        control_flush_error     = 21
        OTHERS                  = 22.

    IF sy-subrc <> 0.
      MESSAGE 'Error on generating sample file' TYPE 'I' DISPLAY LIKE 'E'.
    ELSE.
      MESSAGE 'File saved' TYPE 'S'.
    ENDIF.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  INIT_LAYOUT_VARIANT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_file_save_dialog USING pv_filename pv_path pv_extension pv_title.
  DATA : lv_fullpath  TYPE string,
         lv_directory TYPE string,
         lv_title     TYPE string,
         lv_extension TYPE string.

  lv_directory = 'C:/'.

  IF pv_title IS INITIAL.
    lv_title = 'FILE SAVE'.
  ELSE.
    lv_title = pv_title.
  ENDIF.
  IF pv_extension IS INITIAL.
    lv_extension = 'xlsx'.
  ELSE.
    lv_extension = pv_extension.
  ENDIF.

  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title      = lv_title
      default_extension = lv_extension
      default_file_name = pv_filename
      initial_directory = lv_directory
    CHANGING
      filename          = pv_filename
      path              = pv_path
      fullpath          = lv_fullpath.

  IF sy-subrc EQ 0.
    pv_path  = lv_fullpath.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  INIT_LAYOUT_VARIANT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM init_layout_variant USING pv_alv_key
                               pv_save
                         CHANGING pv_vari .
  CLEAR : gs_alv_variant.

  gs_alv_variant-report   = sy-repid.
  gs_alv_variant-username = sy-uname.
  gs_alv_variant-handle   = pv_alv_key.

  CALL FUNCTION 'LVC_VARIANT_DEFAULT_GET'
    EXPORTING
      i_save        = pv_save
    CHANGING
      cs_variant    = gs_alv_variant
    EXCEPTIONS
      wrong_input   = 1
      not_found     = 2
      program_error = 3
      OTHERS        = 4.

  IF sy-subrc = 0.
    pv_vari = gs_alv_variant-variant.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SET_LAYOUT_VARIANT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_layout_variant USING pv_alv_key
                              pv_save
                        CHANGING pv_vari .

  CLEAR : gs_alv_variant.

* ALV Layout variant
  IF NOT pv_vari IS INITIAL.
    MOVE : sy-repid   TO gs_alv_variant-report,
           sy-uname   TO gs_alv_variant-username,
           pv_vari    TO gs_alv_variant-variant,
           pv_alv_key TO gs_alv_variant-handle.

    CALL FUNCTION 'REUSE_ALV_VARIANT_EXISTENCE'
      EXPORTING
        i_save        = pv_save
      CHANGING
        cs_variant    = gs_alv_variant
      EXCEPTIONS
        wrong_input   = 1
        not_found     = 2
        program_error = 3.
  ELSE.

    PERFORM init_layout_variant USING pv_alv_key pv_save CHANGING pv_vari.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_LOCAL_TIME
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_BALV_ERDAT  text
*      -->P_GT_BALV_ERZET  text
*----------------------------------------------------------------------*
FORM get_local_time  USING    pv_date
                              pv_time.

  IF sy-zonlo IS NOT INITIAL AND c_tz_system <> sy-zonlo."local time zone이 세팅 된 경우만
    CONVERT DATE pv_date TIME pv_time
    INTO TIME STAMP gv_timestamp TIME ZONE c_tz_system.

    CONVERT TIME STAMP gv_timestamp TIME ZONE sy-zonlo
    INTO DATE pv_date TIME pv_time.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  GET_SYSTEM_TIME
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_BALV_ERDAT  text
*      -->P_GT_BALV_ERZET  text
*----------------------------------------------------------------------*
FORM get_system_time  USING    pv_date
                               pv_time.
  IF sy-zonlo IS NOT INITIAL AND c_tz_system <> sy-zonlo."local time zone이 세팅 된 경우만
    CONVERT DATE pv_date TIME pv_time
    INTO TIME STAMP gv_timestamp TIME ZONE sy-zonlo.

    CONVERT TIME STAMP gv_timestamp TIME ZONE c_tz_system
    INTO DATE pv_date TIME pv_time.
  ELSE.
    CONVERT DATE pv_date TIME pv_time
    INTO TIME STAMP gv_timestamp TIME ZONE c_tz_dhtc.

    CONVERT TIME STAMP gv_timestamp TIME ZONE c_tz_system
    INTO DATE pv_date TIME pv_time.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CREATE_INIT_DYN_OBJ
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->  text
*      -->  text
*----------------------------------------------------------------------*
FORM create_init_dyn_obj.
  TYPES: BEGIN OF tdynp,
           prog TYPE d020s-prog,
           dnum TYPE d020s-dnum,
         END OF tdynp.

  DATA xdynp TYPE tdynp.
  DATA: xdyn_head TYPE  d020s.
  DATA: idyn_fldl TYPE TABLE OF d021s,
        idyn_flow TYPE TABLE OF d022s,
        idyn_mcod TYPE TABLE OF d023s.
  DATA xdyn_text TYPE d020t-dtxt.
  xdyn_head-prog = sy-repid.
  xdyn_head-dnum = '0100'.


  CALL FUNCTION 'RPY_DYNPRO_READ'
    EXPORTING
      progname         = xdyn_head-prog
      dynnr            = xdyn_head-dnum
    EXCEPTIONS
      cancelled        = 1
      not_found        = 2
      permission_error = 3
      OTHERS           = 4.
  IF sy-subrc EQ 0.
    EXIT.
  ENDIF.


  xdyn_head-fnum = '0100'.
  xdyn_head-bzmx = '0'.
  xdyn_head-bzbr = '0'.
  xdyn_head-mili = '192'.
  xdyn_head-mico = '37'.
  xdyn_head-mali = '0'.
  xdyn_head-maco = '0'.
  xdyn_head-noli = '27'.
  xdyn_head-noco = '120'.
  xdyn_head-valp = '0'.
  xdyn_head-cuan = 'G'.
  xdyn_head-spra = sy-langu.
  xdyn_head-cupo = ''.
  xdyn_head-dgen = sy-datum.
  xdyn_head-tgen = sy-uzeit.
  xdyn_text = 'List'.

  idyn_fldl = VALUE #( ( fnam = 'GV_OKCODE' didx = '0000' flg1 = '80' flg2 = '10' flg3 = '00' fmb1 = '00'
                         fmb2 = '00' leng = '14' line = 'FF' coln = '01' ltyp = 'O' lanf = '00'
                         lblk = '00' lrep = '00' type = 'CHAR' aglt = '00' adez = '00' stxt = '____________________'
                         res1 = '                                       00' ) ).
  idyn_flow = VALUE #( ( line = '' )
  ( line = 'PROCESS BEFORE OUTPUT.' )
  ( line = '  MODULE set_screen.' )
  ( line = '  MODULE set_alv.' )
  ( line = 'PROCESS AFTER INPUT.' )
  ( line = '  MODULE exit_screen AT EXIT-COMMAND.' )
  ( line = '  MODULE user_command.' ) ).

  CALL FUNCTION 'RPY_DYNPRO_INSERT_NATIVE'
    EXPORTING
*     suppress_corr_checks           = ' '
*     CORRNUM            = ' '
      header             = xdyn_head
      dynprotext         = xdyn_text
*     SUPPRESS_EXIST_CHECKS          = ' '
*     USE_CORRNUM_IMMEDIATEDLY       = ' '
*     SUPPRESS_COMMIT_WORK           = ' '
    TABLES
      fieldlist          = idyn_fldl
      flowlogic          = idyn_flow
      params             = idyn_mcod
    EXCEPTIONS
      cancelled          = 1
      already_exists     = 2
      program_not_exists = 3
      not_executed       = 4
      OTHERS             = 5.

  DATA _program TYPE  trdir-name.

  DATA: ista TYPE TABLE OF rsmpe_stat,
        ifun TYPE TABLE OF rsmpe_funt,
        imen TYPE TABLE OF rsmpe_men,
        imtx TYPE TABLE OF rsmpe_mnlt,
        iact TYPE TABLE OF rsmpe_act,
        ibut TYPE TABLE OF rsmpe_but,
        ipfk TYPE TABLE OF rsmpe_pfk,
        iset TYPE TABLE OF rsmpe_staf,
        idoc TYPE TABLE OF rsmpe_atrt,
        itit TYPE TABLE OF rsmpe_titt,
        ibiv TYPE TABLE OF rsmpe_buts.
  DATA xadm   TYPE rsmpe_adm.
  DATA xtrkey TYPE trkey.






  _program = sy-repid.

  xtrkey-obj_type = 'PROG'.
  xtrkey-obj_name = _program.
  xtrkey-sub_type = 'CUAD'.
  xtrkey-sub_name = _program.

*
  xadm-actcode = '000001'.
  xadm-pfkcode = '000001'.

  ista = VALUE #( ( code = '0100' modal = 'D' actcode = '000001'
                    pfkcode = '000001' butcode = '0000' int_note = 'Status' ) ).

  ifun = VALUE #(
  ( code = 'BACK' textno = '001' type = 'E' text_type = 'S' text_name = 'ICON_SYSTEM_BACK' icon_id = '@2M@' fun_text = 'Back' )
  ( code = 'CANC' textno = '001' type = 'E' text_type = 'S' text_name = 'ICON_SYSTEM_CANCEL' icon_id = '@2O@' fun_text = 'Cancel' )
  ( code = 'EXIT' textno = '001' type = 'E' text_type = 'S' text_name = 'ICON_SYSTEM_END' icon_id = '@2N@' fun_text = 'Exit' )
  ( code = 'SAVE' textno = '001' type = ' ' text_type = 'S' text_name = 'ICON_SYSTEM_SAVE' icon_id = '@2L@' fun_text = 'Save' )
  ).


  ipfk = VALUE #( ( code = '000001' pfno = '03' funcode = 'BACK' funno = '001' )
  ( code = '000001' pfno = '11' funcode = 'SAVE' funno = '001' )
  ( code = '000001' pfno = '12' funcode = 'CANC' funno = '001' )
  ( code = '000001' pfno = '15' funcode = 'EXIT' funno = '001' ) ).

  iset = VALUE #( ( status = '0100' function = 'BACK' )
  ( status = '0100' function = 'CANC' )
  ( status = '0100' function = 'EXIT' )
  ( status = '0100' function = 'SAVE' ) ).

  idoc = VALUE #( ( obj_type = 'A' obj_code = '000001' sub_code = '' modal = 'D' int_note = 'Status' )
  ( obj_type = 'P' obj_code = '000001' sub_code = '' modal = 'D' int_note = 'Status' )
  ( obj_type = 'B' obj_code = '000001' sub_code = '0001' modal = 'D' int_note = 'Status' ) ).

  itit = VALUE #( ( code = '0100' text = '&' ) ).

  CALL FUNCTION 'RS_CUA_INTERNAL_WRITE'
    EXPORTING
      program   = _program
      language  = sy-langu
      tr_key    = xtrkey
      adm       = xadm
      state     = 'I'
    TABLES
      sta       = ista
      fun       = ifun
      men       = imen
      mtx       = imtx
      act       = iact
      but       = ibut
      pfk       = ipfk
      set       = iset
      doc       = idoc
      tit       = itit
      biv       = ibiv
    EXCEPTIONS
      not_found = 1
      OTHERS    = 2.


  DATA  BEGIN OF hirst2 OCCURS 200.
  INCLUDE STRUCTURE textpool.
  DATA  END OF hirst2.

  CLEAR hirst2.
  hirst2-id = 'R'.
  hirst2-key = ''.
  hirst2-entry = _program.
  hirst2-length = '26'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'T00'.
  hirst2-entry = _program.
  hirst2-length = '26'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'B01'.
  hirst2-entry = 'Download'.
  hirst2-length = '20'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'T01'.
  hirst2-entry = 'Display'.
  hirst2-length = '20'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'T02'.
  hirst2-entry = 'Upload'.
  hirst2-length = '20'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'T03'.
  hirst2-entry = 'File Path'.
  hirst2-length = '20'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'T04'.
  hirst2-entry = 'Sample Excel'.
  hirst2-length = '20'.
  APPEND hirst2.

  CLEAR hirst2.
  hirst2-id = 'I'.
  hirst2-key = 'T09'.
  hirst2-entry = 'Select Options'.
  hirst2-length = '20'.
  APPEND hirst2.

  INSERT TEXTPOOL _program FROM hirst2 LANGUAGE sy-langu.
ENDFORM.
