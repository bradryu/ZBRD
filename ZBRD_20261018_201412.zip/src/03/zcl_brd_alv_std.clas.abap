*************************************************************************
* 이 프로그램은 저작권 법에 따라 보호받는 BR Developer Group의 지적 재산으로서,
* 무단 사용, 무단 복제하는 행위는 금지되어 있으며 법적제재를 받을 수 있습니다.
* 한국 저작권 위원회 등록번호 : C-2018-000076
* Copyright 2018 BR Developer Group All right reserved.
* http://www.brdev.co.kr:8080/flp
* bradryu@hotmail.com
*************************************************************************
class ZCL_BRD_ALV_STD definition
  public
  inheriting from CL_GUI_ALV_GRID
  final
  create public .

public section.

  types:
    BEGIN OF ts_header_config,
        mandt             TYPE  mandt,
        progid            TYPE  cprog,
        alv_key           TYPE  char10,
        zcreate           TYPE  char01,
        zupdate           TYPE  char01,
        zdelete           TYPE  char01,
        zrefresh          TYPE  char01,
        zexcel            TYPE  char01,
        db_click          TYPE  char01,
        after_refresh     TYPE  char01,
        use_flag          TYPE  flag,
        zhelp             TYPE  char01,
        zebra             TYPE  lvc_zebra,
        edit              TYPE  lvc_edit,
        edit_mode         TYPE  lvc_edmo,
        no_keyfix         TYPE  lvc_nokfix,
        frontend          TYPE  lvc_front,
        object_key        TYPE  bds_typeid,
        doc_id            TYPE  bds_docid,
        template          TYPE  bds_filena,
        language          TYPE  lang,
        graphics          TYPE  guid_32,
        smalltitle        TYPE  lvc_titsz,
        no_hgridln        TYPE  lvc_hgrid,
        no_vgridln        TYPE  lvc_vgrid,
        no_headers        TYPE  lvc_heads,
        no_merging        TYPE  lvc_merge,
        cwidth_opt        TYPE  lvc_cwo,
        totals_bef        TYPE  lvc_totbef,
        no_totarr         TYPE  char01,
        no_totexp         TYPE  char01,
        no_rowmove        TYPE  char01,
        no_rowins         TYPE  char01,
        no_colexpd        TYPE  char01,
        no_f4             TYPE  char01,
        countfname        TYPE  lvc_fname,
        col_opt           TYPE  char01,
        val_data          TYPE  char01,
        blob_scope        TYPE  salv_bs_blob_scope,
        blob_flavour      TYPE  salv_bs_blob_flavour,
        blob_name         TYPE  salv_bs_blob_name,
        blob_key          TYPE  slis_blob_key,
        blob_type         TYPE  slis_blob_type,
        stylefname        TYPE  lvc_fname,
        no_rowmark        TYPE  lvc_rowmk,
        no_toolbar        TYPE  lvc_toolb,
        grid_title        TYPE  lvc_title,
        sel_mode          TYPE  lvc_libox,
        box_fname         TYPE  lvc_fname,
        sgl_clk_hd        TYPE  lvc_sglclh,
        no_totline        TYPE  lvc_nototl,
        numc_total        TYPE  lvc_numcto,
        no_utsplit        TYPE  lvc_unitsp,
        excp_fname        TYPE  lvc_exfnm,
        excp_rolln        TYPE  lvc_exrol,
        excp_conds        TYPE  lvc_excon,
        excp_led          TYPE  lvc_exled,
        excp_group        TYPE  lvc_exgrp,
        detailinit        TYPE  lvc_detini,
        detailtitl        TYPE  lvc_dettit,
        keyhot            TYPE  lvc_keyhot,
        no_author         TYPE  lvc_noauth,
        xifunckey         TYPE  aqs_xikey,
        xidirect          TYPE  flag,
        info_fname        TYPE  lvc_cifnm,
        ctab_fname        TYPE  lvc_ctfnm,
        weblook           TYPE  lvc_look,
        webstyle          TYPE  lvc_style,
        webrows           TYPE  lvc_webrow,
        webxwidth         TYPE  int4,
        webxheight        TYPE  int4,
        optimize_all_cols TYPE  char01,
        change_evt        TYPE  char01,
        ernam             TYPE  ernam,
        erdat             TYPE  erdat,
        erzet             TYPE  /ui2/fcm_created_at,
        aenam             TYPE  aenam,
        aedat             TYPE  aedat,
        aezet             TYPE  /ui2/fcm_changed_at,
        zdel              TYPE  flag,
      END OF ts_header_config .
  types:
    BEGIN OF ts_fcat_config,
        mandt          TYPE mandt,
        progid         TYPE cprog,
        alv_key        TYPE char10,
        fcat_key       TYPE char10,
        fieldname      TYPE lvc_fname,
        row_pos        TYPE lvc_rowpos,
        col_pos        TYPE lvc_colpos,
        tabname        TYPE lvc_tname,
        currency       TYPE lvc_curr,
        cfieldname     TYPE lvc_cfname,
        quantity       TYPE lvc_quan,
        qfieldname     TYPE lvc_qfname,
        ifieldname     TYPE lvc_fname,
        round          TYPE lvc_round,
        exponent       TYPE lvc_expont,
        zkey           TYPE lvc_key,
        key_sel        TYPE lvc_keysel,
        icon           TYPE lvc_icon,
        symbol         TYPE lvc_symbol,
        checkbox       TYPE lvc_checkb,
        just           TYPE lvc_just,
        lzero          TYPE lvc_lzero,
        no_sign        TYPE lvc_nosign,
        no_zero        TYPE lvc_nozero,
        no_convext     TYPE lvc_noconv,
        edit_mask      TYPE lvc_edtmsk,
        emphasize      TYPE lvc_emphsz,
        fix_column     TYPE lvc_fixcol,
        do_sum         TYPE lvc_dosum,
        no_sum         TYPE lvc_nosum,
        no_out         TYPE lvc_noout,
        tech           TYPE lvc_tech,
        outputlen      TYPE lvc_outlen,
        convexit       TYPE convexit,
        seltext        TYPE lvc_txt,
        tooltip        TYPE lvc_tip,
        rollname       TYPE lvc_roll,
        datatype       TYPE datatype_d,
        inttype        TYPE inttype,
        intlen         TYPE intlen,
        lowercase      TYPE lowercase,
        reptext        TYPE reptext,
        hier_level     TYPE lvc_hierl,
        reprep         TYPE lvc_crprp,
        domname        TYPE domname,
        sp_group       TYPE lvc_spgrp,
        hotspot        TYPE lvc_hotspt,
        dfieldname     TYPE lvcdbgfn,
        col_id         TYPE lvc_colid,
        f4availabl     TYPE ddf4avail,
        auto_value     TYPE lvc_auto,
        checktable     TYPE tabname,
        valexi         TYPE valexi,
        web_field      TYPE lvc_fname,
        href_hndl      TYPE int4,
        style          TYPE lvc_style,
        style2         TYPE lvc_style,
        style3         TYPE lvc_style,
        style4         TYPE lvc_style,
        drdn_hndl      TYPE int4,
        drdn_field     TYPE lvc_fname,
        no_merging     TYPE char01,
        h_ftype        TYPE lvc_ftype,
        col_opt        TYPE lvc_colopt,
        no_init_ch     TYPE char01,
        drdn_alias     TYPE char01,
        decfloat_style TYPE outputstyle,
        parameter0     TYPE char30,
        parameter1     TYPE char30,
        parameter2     TYPE char30,
        parameter3     TYPE char30,
        parameter4     TYPE char30,
        parameter5     TYPE int4,
        parameter6     TYPE int4,
        parameter7     TYPE int4,
        parameter8     TYPE int4,
        parameter9     TYPE int4,
        ref_field      TYPE lvc_rfname,
        ref_table      TYPE lvc_rtname,
        txt_field      TYPE lvc_fname,
        roundfield     TYPE lvc_rndfn,
        decimals_o     TYPE lvc_decmls,
        decmlfield     TYPE lvc_dfname,
        dd_outlen      TYPE lvc_ddlen,
        decimals       TYPE decimals,
        coltext        TYPE lvc_txtcol,
        scrtext_l      TYPE scrtext_l,
        scrtext_m      TYPE scrtext_m,
        scrtext_s      TYPE scrtext_s,
        colddictxt     TYPE lvc_ddict,
        selddictxt     TYPE lvc_ddict,
        tipddictxt     TYPE lvc_ddict,
        crea_edit      TYPE lvc_edit,
        chan_edit      TYPE lvc_edit,
        upld_edit      TYPE lvc_edit,
        tech_col       TYPE lvc_tcol,
        tech_form      TYPE lvc_tform,
        tech_comp      TYPE lvc_tcomp,
        hier_cpos      TYPE lvchcolpos,
        h_col_key      TYPE tv_itmname,
        h_select       TYPE lvc_select,
        dd_roll        TYPE rollname,
        dragdropid     TYPE lvc_ddid,
        mac            TYPE char01,
        indx_field     TYPE int4,
        indx_cfiel     TYPE int4,
        indx_qfiel     TYPE int4,
        indx_ifiel     TYPE int4,
        indx_round     TYPE int4,
        indx_decml     TYPE int4,
        get_style      TYPE char01,
        mark           TYPE char01,
        sr_spos        TYPE slis_spos,
        sr_up          TYPE char1,
        sr_down        TYPE char1,
        sr_group       TYPE slis_ctrls,
        sr_subtot      TYPE slis_dosub,
        sr_comp        TYPE char1,
        sr_expa        TYPE char1,
        sr_seltext     TYPE slis_scrit,
        sr_obligatory  TYPE char1,
        sr_level       TYPE int4,
        sr_no_out      TYPE char1,
        sr_intopt      TYPE lvciflag,
        button         TYPE char1,
        change_evt     TYPE char1,
        ernam          TYPE ernam,
        erdat          TYPE erdat,
        erzet          TYPE /ui2/fcm_created_at,
        aenam          TYPE aenam,
        aedat          TYPE aedat,
        aezet          TYPE /ui2/fcm_changed_at,
        zdel           TYPE flag,
      END OF ts_fcat_config .
  types:
    tt_fcat_config TYPE TABLE OF ts_fcat_config .
  types:
    BEGIN OF ts_key_text,
        key  TYPE char40,
        text TYPE char80,
      END OF ts_key_text .
  types:
    tt_key_text TYPE TABLE OF ts_key_text .
  types:
    BEGIN OF ts_txt,
        line(4096) TYPE c,
      END OF ts_txt .
  types:
    tt_txt TYPE TABLE OF ts_txt .

  class-data MC_DISPLAY_MODE type CHAR04 value 'DISP' ##NO_TEXT.
  class-data MC_UPLOAD_MODE type CHAR04 value 'UPLD' ##NO_TEXT.
  class-data MC_CANCEL_MODE type CHAR04 value 'CANC' ##NO_TEXT.
  class-data MC_CREATE_MODE type CHAR04 value 'CREA' ##NO_TEXT.
  class-data MC_CHANGE_MODE type CHAR04 value 'CHAN' ##NO_TEXT.
  data MT_FIELDCAT type LVC_T_FCAT .
  class-data:
    BEGIN OF mc_icon READ-ONLY,
        create     TYPE icon-id VALUE icon_create,
        insert_row TYPE icon-id VALUE icon_insert_row,
        change     TYPE icon-id VALUE icon_change,
        xls        TYPE icon-id VALUE icon_xls,
        cancel     TYPE icon-id VALUE icon_cancel,
        refresh    TYPE icon-id VALUE icon_refresh,
        delete_row TYPE icon-id VALUE icon_delete_row,
        delete     TYPE icon-id VALUE icon_delete,
        defect     TYPE  icon-id VALUE icon_defect,
      END OF mc_icon .
  class-data:
    BEGIN OF mc_msg,
        no_row_select        TYPE char10 VALUE 'M100000001',
        no_change_data_found TYPE char10 VALUE 'M100000002',
        save_error           TYPE char10 VALUE 'M100000003',
        save_success         TYPE char10 VALUE 'M100000004',
        input_mandatory      TYPE char10 VALUE 'M100000005',
      END OF mc_msg .
  class-data:
    BEGIN OF mc_ucomm READ-ONLY,
        refresh  TYPE ui_func  VALUE 'RFSH', "Refresh
        create   TYPE ui_func  VALUE 'CREA', "Create
        insert   TYPE ui_func  VALUE 'INST', "Insert
        change   TYPE ui_func  VALUE 'CHAN', "Change
        display  TYPE ui_func  VALUE 'DISP', "Display
        delete   TYPE ui_func  VALUE 'DELE', "Delete
        xls      TYPE ui_func  VALUE '$XLS', "Excel
        upload   TYPE ui_func  VALUE 'UPLD', "Upload
        download TYPE ui_func  VALUE '&XXL', "Download
        cancel   TYPE ui_func  VALUE 'CANC', "Cancle
        excute   TYPE ui_func  VALUE 'EXEC', "Excute
        open     TYPE ui_func  VALUE 'OPEN', "Excute
        back     TYPE sy-ucomm  VALUE 'BACK', "Back
        exit     TYPE sy-ucomm  VALUE 'EXIT', "Exit
        save     TYPE sy-ucomm  VALUE 'SAVE', "Save
        simulate TYPE sy-ucomm  VALUE 'SIMU', "Simulate
        print    TYPE sy-ucomm  VALUE 'PRNT', "Print
        dbclick  TYPE sy-ucomm  VALUE 'DBCLK', "Double Click
        help     TYPE sy-ucomm  VALUE 'BAHP', "BALV Help
      END OF mc_ucomm .

  methods CONSTRUCTOR
    importing
      value(IV_PARENT) type C optional
      value(IV_PROGID) type SY-CPROG default SY-CPROG
      value(IV_ALV_KEY) type CHAR10 default 'BALV'
      value(IV_FCAT_KEY) type CHAR10 default 'DEFAULT'
      value(IO_PARENT) type ref to CL_GUI_CONTAINER optional
      value(IV_LIFETIME) type I optional
      value(IV_APPL_EVENTS) type CHAR1 optional
      !IV_CALLBACK_PROGID type SY-CPROG default SY-CPROG
      !IS_LAYOUT_CBO type TS_HEADER_CONFIG
    exceptions
      ERROR_CNTL_CREATE
      ERROR_CNTL_INIT
      ERROR_CNTL_LINK
      ERROR_DP_CREATE .
  methods DISPLAY
    importing
      !IV_MODE type CHAR04 default 'DISP'
      !IT_TOOLBAR_EXCLUDING type UI_FUNCTIONS optional
      !IV_FCAT_KEY type CHAR10 optional
      !IT_SORTCAT type LVC_T_SORT optional
      !IT_DROP_DOWN type LVC_T_DRAL optional
      !IV_SAVE type CHAR01 default 'A'
      !IV_DEFAULT type CHAR01 default 'X'
      !IS_VARIANT type DISVARIANT optional
      !IT_FIELDCAT_CBO type TT_FCAT_CONFIG optional
    changing
      !CT_DATA type TABLE .
  class-methods CATCH_EXCEPTION
    importing
      !IO_ROOT type ref to CX_ROOT .
  class-methods COMMIT_DELETE
    importing
      !IV_COUNT type I optional .
  class-methods COMMIT_SAVE
    importing
      !IV_COUNT type I optional .
  class-methods CONFIRM_CANCEL
    returning
      value(RV_RETURN) type CHAR1 .
  class-methods CONFIRM_DELETE
    returning
      value(RV_RETURN) type CHAR1 .
  class-methods CONFIRM_MSG
    importing
      !IV_TITLE type CHAR255
      !IV_QUESTION type CHAR255
      !IV_BTN1 type CHAR10 default 'YES'
      !IV_BTN2 type CHAR10 default 'NO'
    returning
      value(RV_RETURN) type CHAR1 .
  class-methods CONFIRM_SAVE
    returning
      value(RV_RETURN) type CHAR1 .
  class-methods EXCEL_DOWNLOAD
    importing
      !IT_DATA type STANDARD TABLE
      !IV_FULL_PATH type STRING
      !IT_HEADER type TT_KEY_TEXT
    exporting
      !EV_SUBRC type I .
  class-methods EXCEL_UPLOAD
    importing
      !IV_FILE_DIALOG type CHAR01 default 'X'
      !IV_FILE_NAME type LOCALFILE optional
      !IV_MAX_ROW_CNT type I default 100000
      !IV_SHEET_NO type I default 1
    changing
      !CT_DATA type STANDARD TABLE
    returning
      value(EV_SUBRC) type SY-SUBRC .
  methods REFRESH
    importing
      !IV_HARD_REFRESH type FLAG optional .
  class-methods ROLLBACK_FAIL .
  methods INSERT_TOOLBAR_BUTTON
    importing
      value(IV_FUNCTION) type UI_FUNC optional
      value(IV_ICON) type ICON_D optional
      value(IV_QUICKINFO) type ICONQUICK optional
      value(IV_BUTN_TYPE) type TB_BTYPE optional
      value(IV_DISABLED) type CHAR1 optional
      value(IV_TEXT) type TEXT40 optional
      value(IV_CHECKED) type CHAR1 optional
      !IV_INDEX type I .
  class-methods MESSAGE_POPUP
    changing
      !CT_MSG type TABLE .
  class-methods MESSAGE_STRIP
    importing
      !IV_CODE type CHAR10
      !IV_PARAM1 type CHAR20 optional
      !IV_PARAM2 type CHAR20 optional
      !IV_PARAM3 type CHAR20 optional
      !IV_PARAM4 type CHAR20 optional
      !IV_TYPE type CHAR1 default 'S'
      !IV_DISPLAY type CHAR1 optional .
  class-methods MESSAGE
    importing
      !IV_CODE type CHAR10
      !IV_PARAM1 type CHAR20 optional
      !IV_PARAM2 type CHAR20 optional
      !IV_PARAM3 type CHAR20 optional
      !IV_PARAM4 type CHAR20 optional
    returning
      value(RV_MSG) type STRING .
  methods IS_CHANGING
    returning
      value(RV_FLAG) type FLAG .
  methods GET_ALV_MODE
    returning
      value(RV_RETURN) type CHAR4 .
  methods SET_CHANGING_FLAG
    importing
      !IV_FLAG type FLAG .
  methods SET_CELLTAB_STYLE
    importing
      !IV_MODE type CHAR04
    changing
      !CT_CELLTAB type LVC_T_STYL .
  class-methods GET_ALV_ITAB
    importing
      !IT_FCAT_CONFIG type TT_FCAT_CONFIG optional
    exporting
      value(EO_DATA) type ref to DATA
      !ET_HEADER_LABEL type STRING_TABLE .
  class-methods ADD_EXCEL_DOWNLOAD_SHEET
    importing
      !IT_DATA type STANDARD TABLE
    exporting
      !EV_SUBRC type I .
  class-methods ADD_EXCEL_FILE_OPEN_DIALOG
    changing
      !CV_FILE type LOCALFILE .
  methods GOTO_ROW_FOCUS
    importing
      !IV_ROWNO type INT4 optional .
  PROTECTED SECTION.

    DATA mv_progid TYPE cprog .
    DATA mv_alv_key TYPE char10 VALUE 'DEFAULT' ##NO_TEXT.
    DATA mv_fcat_key TYPE char10 VALUE 'DEFAULT' ##NO_TEXT.
    DATA ms_layout TYPE lvc_s_layo .
    DATA ms_fieldcat TYPE lvc_s_fcat .
    DATA ms_header_config TYPE ts_header_config .
    DATA mv_mode TYPE char04 VALUE 'DISP' ##NO_TEXT.
    DATA mv_is_reload TYPE char1 .
    DATA mt_sortcat TYPE lvc_t_sort .
    DATA mv_callback_progid TYPE cprog .
    DATA mv_bukrs TYPE bukrs .
    DATA mv_bukrs_waers TYPE waers .
    CONSTANTS mc_bukrs_waers TYPE waers VALUE 'KRW' ##NO_TEXT.
    DATA ms_config_fieldcat TYPE ts_fcat_config .
    DATA mt_config_fieldcat TYPE tt_fcat_config .
    DATA ms_variant TYPE disvariant .
    DATA mv_tabix TYPE sy-tabix .
    DATA mt_f4_field TYPE lvc_t_f4 .
    DATA ms_f4_field TYPE lvc_s_f4 .
    DATA mv_is_f4_exists TYPE char01 .
    CLASS-DATA mo_excel TYPE ole2_object .
    CLASS-DATA mo_workbooks TYPE ole2_object .
    CLASS-DATA mo_workbook TYPE ole2_object .
    CLASS-DATA mo_sheets TYPE ole2_object .
    CLASS-DATA mo_sheet TYPE ole2_object .
    CLASS-DATA mv_sheet_num TYPE i VALUE 1 ##NO_TEXT.
    DATA ms_col_id TYPE lvc_s_col .
    DATA ms_row_id TYPE lvc_s_row .
    DATA mo_html_viewer TYPE REF TO cl_gui_html_viewer .
    DATA mv_is_field_button_exists TYPE char01 .
    DATA mv_is_hot_spot_exists TYPE char01 .
    DATA mv_is_set_change_evt TYPE char01 .
    DATA mv_on_chainging_flag TYPE flag .

    METHODS handle_after_refresh
        FOR EVENT after_refresh OF cl_gui_alv_grid .
    METHODS handle_button_click
        FOR EVENT button_click OF cl_gui_alv_grid
      IMPORTING
        !es_col_id
        !es_row_no .
    METHODS handle_data_changed
        FOR EVENT data_changed OF cl_gui_alv_grid
      IMPORTING
        !er_data_changed
        !e_onf4
        !e_onf4_before
        !e_onf4_after
        !e_ucomm .
    METHODS handle_double_click
        FOR EVENT double_click OF cl_gui_alv_grid
      IMPORTING
        !e_row
        !e_column
        !es_row_no .
    METHODS handle_hotspot_click
        FOR EVENT hotspot_click OF cl_gui_alv_grid
      IMPORTING
        !e_row_id
        !e_column_id
        !es_row_no .
    METHODS handle_onf4
        FOR EVENT onf4 OF cl_gui_alv_grid
      IMPORTING
        !e_fieldname
        !e_fieldvalue
        !es_row_no
        !er_event_data
        !et_bad_cells
        !e_display .
    METHODS handle_toolbar
        FOR EVENT toolbar OF cl_gui_alv_grid
      IMPORTING
        !e_object
        !e_interactive .
    METHODS handle_user_command
        FOR EVENT user_command OF cl_gui_alv_grid
      IMPORTING
        !e_ucomm .
private section.

  data MO_CL_MENU_XLS type ref to CL_CTMENU .

  methods GET_DDL_BY_DOMAIN
    importing
      !IV_DOMNAME type DD07L-DOMNAME
      !IV_TEXT type DDREFSTRUC-BOOL default SPACE
      !IV_LANGU type DD07T-DDLANGUAGE default SPACE
      !IV_BYPASS_BUFFER type DDREFSTRUC-BOOL default SPACE
      !IV_DDL_NUMBER type INT4
    returning
      value(RT_DDL) type LVC_T_DRAL .
  methods GET_DROP_DOWN_CONFIG
    changing
      !CT_DROP_DOWN type LVC_T_DRAL .
  methods SET_DEFAULT_EXCLUDE_TOOLBAR .
  methods SET_DEFAULT_FIELDCAT
    importing
      !IT_DATA type TABLE .
  methods SET_EVENTS .
  methods SET_FIELDCAT .
ENDCLASS.



CLASS ZCL_BRD_ALV_STD IMPLEMENTATION.


  METHOD add_excel_download_sheet.
    MESSAGE 'The traial version does not support Excel functions.' TYPE 'I' DISPLAY LIKE 'E'.

  ENDMETHOD.


  METHOD add_excel_file_open_dialog.
    MESSAGE 'The traial version does not support Excel functions.' type 'I' DISPLAY LIKE 'E'.
  ENDMETHOD.


  METHOD catch_exception.
    DATA lv_text TYPE string.
    lv_text = io_root->get_text( ).
    MESSAGE lv_text TYPE 'I' DISPLAY LIKE 'E'.
  ENDMETHOD.


  METHOD commit_delete.
    DATA lv_str TYPE string .

    IF iv_count EQ 0.
      MESSAGE 'Data Deleted!!' TYPE 'S'.
    ELSE.
      lv_str = iv_count.

      CONCATENATE lv_str  `Record(s) Deleted!!`  INTO lv_str.
      MESSAGE lv_str TYPE 'S'.
    ENDIF.

    COMMIT WORK.
  ENDMETHOD.


  METHOD commit_save.
    DATA lv_str TYPE string.

    IF iv_count EQ 0.
      MESSAGE 'Data Saved!!' TYPE 'S'.
    ELSE.
      lv_str = iv_count.
      CONCATENATE lv_str ` Record(s) Saved!!` INTO lv_str.
      MESSAGE lv_str TYPE 'S'.
    ENDIF.

    COMMIT WORK.
  ENDMETHOD.


  METHOD confirm_cancel.

    confirm_msg( EXPORTING iv_title = 'Cancel Confirm'
                           iv_question = 'Are you sure to cancel without saving?'
                 RECEIVING rv_return = rv_return ).


  ENDMETHOD.


  METHOD confirm_delete.
    confirm_msg( EXPORTING iv_title = 'Delete Confirm'
                           iv_question = 'Delete Data?'
                 RECEIVING rv_return = rv_return ).

  ENDMETHOD.


  METHOD confirm_msg.
    DATA:lt_spar TYPE TABLE OF spar.
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = iv_title
        diagnose_object       = space
        text_question         = iv_question
        text_button_1         = iv_btn1
        icon_button_1         = space
        text_button_2         = iv_btn2
        icon_button_2         = space
        default_button        = '1'
        display_cancel_button = 'X'
        userdefined_f1_help   = space
        start_column          = 25
        start_row             = 6
        popup_type            = space
        iv_quickinfo_button_1 = space
        iv_quickinfo_button_2 = space
      IMPORTING
        answer                = rv_return
      TABLES
        parameter             = lt_spar
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
    CASE rv_return.
      WHEN '1'. rv_return = abap_true.
      WHEN OTHERS. rv_return = abap_false.
    ENDCASE.
  ENDMETHOD.


  METHOD confirm_save.
    confirm_msg( EXPORTING iv_title = 'Save Confirm'
                           iv_question = 'Save Data?'
                 RECEIVING rv_return = rv_return ).


  ENDMETHOD.


  METHOD constructor.
    DATA : lo_parent TYPE REF TO cl_gui_container,
           lo_custom TYPE REF TO cl_gui_custom_container.

    IF io_parent IS NOT INITIAL.
      lo_parent = io_parent.
    ELSE.
      IF iv_parent IS NOT INITIAL.
        CREATE OBJECT lo_custom
          EXPORTING
            container_name = iv_parent.
*        lo_parent ?= NEW cl_gui_custom_container( container_name = iv_parent ).
        lo_parent ?= lo_custom.
      ELSE.
        lo_parent = cl_gui_container=>default_screen.
      ENDIF.
    ENDIF.

    super->constructor( EXPORTING i_parent = lo_parent
                                  i_lifetime = iv_lifetime
                                  i_appl_events = iv_appl_events ).

    CLEAR mv_is_reload .
    mv_progid = iv_progid.
    mv_callback_progid = iv_callback_progid.

    MOVE-CORRESPONDING is_layout_cbo TO ms_header_config.
    MOVE-CORRESPONDING is_layout_cbo TO ms_layout.

    IF iv_alv_key IS NOT INITIAL.
      mv_alv_key = iv_alv_key.
    ENDIF.
    IF iv_fcat_key IS NOT INITIAL.
      mv_fcat_key = iv_fcat_key.
    ENDIF.

    mv_bukrs_waers = mc_bukrs_waers.

  ENDMETHOD.


  METHOD display.
    DATA : lt_exclude_toolbar TYPE ui_functions,
           lt_drop_down       TYPE lvc_t_dral,
           lv_save,
           lv_str             TYPE string.

    FIELD-SYMBOLS : <ls_data_line> TYPE any,
                    <lt_celltab>   TYPE lvc_t_styl,
                    <lt_coltab>    TYPE lvc_t_scol,
                    <lt_outtab>    TYPE STANDARD TABLE.
    DATA ls_layout TYPE lvc_s_layo.

    " 1. 출력 데이터 존재 확인
    IF ct_data IS NOT REQUESTED.
      IF mt_outtab IS INITIAL.
        MESSAGE 'No Data Found' TYPE 'I' DISPLAY LIKE 'E'.
      ELSE.
        ASSIGN mt_outtab->* TO <lt_outtab>.
      ENDIF.
    ELSE.
      ASSIGN ct_data TO <lt_outtab>.
    ENDIF.

    " 3. 파라미터 확인
    mv_mode = iv_mode.
    IF iv_fcat_key IS NOT INITIAL.
      mv_fcat_key = iv_fcat_key.
    ENDIF.


    IF it_fieldcat_cbo IS INITIAL.
      set_default_fieldcat( EXPORTING it_data = <lt_outtab> ).
    ELSE.
      mt_config_fieldcat = it_fieldcat_cbo.
      SORT mt_config_fieldcat BY fieldname.
      set_fieldcat( ).
    ENDIF.

    " 4. dropdown list 세팅
    CLEAR lt_drop_down.
    lt_drop_down = it_drop_down.
    get_drop_down_config( CHANGING ct_drop_down  = lt_drop_down ).
    IF lt_drop_down IS NOT INITIAL.
      set_drop_down_table( EXPORTING it_drop_down_alias = lt_drop_down ).
    ENDIF.

    " 5. 최초 실행시 세팅
    CLEAR : ms_variant-variant.
    IF mv_is_reload NE abap_true.

      set_events( ). " 이벤트 리스너

      IF it_toolbar_excluding IS INITIAL. " toolbar
        set_default_exclude_toolbar( ).
      ELSE.
        mt_excluding_toolbar = it_toolbar_excluding.
      ENDIF.

      mt_sortcat = it_sortcat. "sort catalog

      " variant설정
      CLEAR : ms_variant.
      IF is_variant IS NOT INITIAL.
        ms_variant = is_variant.
      ELSE.
        ms_variant-report   = mv_progid.
        ms_variant-username = sy-uname.
        ms_variant-handle   = ms_header_config-alv_key.

        CALL FUNCTION 'LVC_VARIANT_DEFAULT_GET'
          EXPORTING
            i_save        = iv_save
          CHANGING
            cs_variant    = ms_variant
          EXCEPTIONS
            wrong_input   = 1
            not_found     = 2
            program_error = 3
            OTHERS        = 4.

        IF sy-subrc EQ 2.
          SELECT SINGLE variant
            INTO ms_variant-variant
            FROM ltdx
           WHERE relid   EQ 'LT'
             AND handle  EQ ms_header_config-alv_key
             AND report  EQ ms_header_config-progid
             AND erfname EQ sy-uname.
        ENDIF.
      ENDIF.

    ENDIF.

    MOVE-CORRESPONDING ms_layout TO ls_layout.
    IF mv_mode EQ mc_upload_mode.
      ls_layout-no_rowins = abap_true.
    ENDIF.

    " 8. alv출력
    CALL METHOD set_table_for_first_display
      EXPORTING
        is_layout            = ls_layout
        it_toolbar_excluding = me->mt_excluding_toolbar
        i_save               = iv_save
        i_default            = iv_default
        is_variant           = ms_variant
      CHANGING
        it_outtab            = <lt_outtab>
        it_sort              = mt_sortcat
        it_fieldcatalog      = mt_fieldcat.


    CASE mv_mode.
      WHEN mc_display_mode.
        CALL METHOD set_ready_for_input
          EXPORTING
            i_ready_for_input = 0.
      WHEN mc_change_mode.
        CALL METHOD set_ready_for_input
          EXPORTING
            i_ready_for_input = 1.
      WHEN mc_upload_mode.
        CALL METHOD set_ready_for_input
          EXPORTING
            i_ready_for_input = 1.
    ENDCASE.


    IF ms_header_config-optimize_all_cols EQ abap_true.
      optimize_all_cols( ).
    ENDIF.
    IF mv_is_reload NE abap_true AND ms_header_config-no_totline NE abap_true.
      mv_tabix = lines( <lt_outtab> ).
      lv_str = mv_tabix.
      CONCATENATE lv_str `Row(s) Listed` INTO lv_str.
      MESSAGE lv_str TYPE 'S'.
    ENDIF.
    mv_is_reload = abap_true.
  ENDMETHOD.


  METHOD excel_download.
    MESSAGE 'The traial version does not support Excel functions.' TYPE 'I' DISPLAY LIKE 'E'.


  ENDMETHOD.


  METHOD excel_upload.

    MESSAGE 'The traial version does not support Excel functions.' TYPE 'I' DISPLAY LIKE 'E'.

  ENDMETHOD.


  METHOD get_alv_itab.
    DATA : lt_fcat TYPE lvc_t_fcat,
           ls_fcat TYPE lvc_s_fcat.
    LOOP AT it_fcat_config ASSIGNING FIELD-SYMBOL(<ls_fcat_config>).
      CLEAR ls_fcat.
      MOVE-CORRESPONDING <ls_fcat_config> TO ls_fcat.
      APPEND ls_fcat TO lt_fcat.
    ENDLOOP.
    DELETE lt_fcat WHERE tech EQ abap_true.
    DELETE lt_fcat WHERE no_out EQ abap_true.

    CALL METHOD cl_alv_table_create=>create_dynamic_table
      EXPORTING
        it_fieldcatalog = lt_fcat
      IMPORTING
        ep_table        = eo_data.

    LOOP AT lt_fcat INTO ls_fcat.
      APPEND ls_fcat-reptext TO et_header_label.
    ENDLOOP.

  ENDMETHOD.


  METHOD get_alv_mode.
    rv_return = mv_mode.
  ENDMETHOD.


  METHOD get_ddl_by_domain.
    DATA : lt_dom	TYPE TABLE OF	dd07v,
           ls_ddl TYPE lvc_s_dral.
    FIELD-SYMBOLS <ls_dom> TYPE dd07v.
    CLEAR : lt_dom, ls_ddl.

    CALL FUNCTION 'DD_DOMVALUES_GET'
      EXPORTING
        domname        = iv_domname
        text           = iv_text
        langu          = iv_langu
        bypass_buffer  = iv_bypass_buffer
      TABLES
        dd07v_tab      = lt_dom
      EXCEPTIONS
        wrong_textflag = 1
        OTHERS         = 2.

    LOOP AT lt_dom ASSIGNING <ls_dom>.
      CLEAR ls_ddl.
      ls_ddl-handle = iv_ddl_number.
      CONCATENATE  <ls_dom>-domvalue_l ` : ` <ls_dom>-ddtext INTO ls_ddl-value.
      ls_ddl-int_value = <ls_dom>-domvalue_l.
      APPEND ls_ddl TO rt_ddl.
    ENDLOOP.
    CLEAR lt_dom[].
  ENDMETHOD.


  METHOD get_drop_down_config.
    DATA : lt_drop_down  TYPE lvc_t_dral,
           ls_drop_down  TYPE lvc_s_dral,
           lv_max_handle TYPE i,
           lv_tabix      TYPE sy-tabix.

    IF ct_drop_down[] IS NOT INITIAL.
      lt_drop_down = ct_drop_down.
      SORT lt_drop_down BY handle DESCENDING.
      READ TABLE lt_drop_down INTO ls_drop_down INDEX 1.
      lv_max_handle = ls_drop_down-handle.
    ELSE.
      lv_max_handle = 0.
    ENDIF.

    LOOP AT mt_fieldcat INTO ms_fieldcat WHERE drdn_alias EQ abap_true
                                           AND drdn_hndl EQ 0
                                           AND drdn_field IS INITIAL
                                           AND domname IS NOT INITIAL.
      lv_tabix = sy-tabix.
      ADD 1 TO lv_max_handle.
      CLEAR lt_drop_down[].
      get_ddl_by_domain( EXPORTING iv_domname = ms_fieldcat-domname
                                   iv_text = abap_true
                                   iv_langu = sy-langu
                                   iv_bypass_buffer = abap_true
                                   iv_ddl_number = lv_max_handle
                         RECEIVING rt_ddl = lt_drop_down ).
      APPEND LINES OF lt_drop_down TO ct_drop_down.
      ms_fieldcat-drdn_hndl = lv_max_handle.
      MODIFY mt_fieldcat FROM ms_fieldcat INDEX lv_tabix.

    ENDLOOP.
  ENDMETHOD.


  METHOD goto_row_focus.
    IF iv_rowno > 0.
      ms_row_id-index = iv_rowno.
    ENDIF.
    set_current_cell_via_id( EXPORTING is_row_id = ms_row_id ).

  ENDMETHOD.


  METHOD handle_after_refresh.

    DATA lv_form_name TYPE string.
    DATA lv_str       TYPE string.
    CONCATENATE mv_alv_key  '_'  'AFTER_REFRESH' INTO lv_form_name.


    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) IF FOUND.
      CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.

  ENDMETHOD.


  METHOD handle_button_click.
    DATA lv_form_name TYPE string.
    DATA lv_str       TYPE string.
    CONCATENATE mv_alv_key '_BUTTON_CLICK' INTO lv_form_name.

    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) USING es_col_id es_row_no IF FOUND.
      CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.

  ENDMETHOD.


  METHOD handle_data_changed.
    DATA : lv_form_name TYPE string,
           ls_mod_cells TYPE lvc_s_modi,
           lv_str       TYPE string.
    DATA : ls_stable      TYPE lvc_s_stbl,
           lv_subrc_main  TYPE sy-subrc VALUE 4,
           lv_subrc_field TYPE sy-subrc VALUE 4.
    DATA lt_mod_cells TYPE lvc_t_modi.

    lt_mod_cells = er_data_changed->mt_good_cells.

    IF ms_header_config-change_evt EQ abap_true.
      TRY.

          CLEAR lv_form_name.
          CONCATENATE ms_header_config-alv_key '_DATA_CHANGED'
                   INTO lv_form_name.
          PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid)
          USING er_data_changed
                e_onf4
                e_onf4_before
                e_onf4_after
                e_ucomm
          IF FOUND.
          lv_subrc_main = 0.
        CATCH cx_sy_dyn_call_param_not_found.
          lv_str = 'data_changed subroutine parameters are not competable!!'.
          MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
      ENDTRY.
    ENDIF.
    CLEAR lv_str.
    TRY.
        LOOP AT lt_mod_cells INTO ls_mod_cells.
          READ TABLE mt_config_fieldcat INTO ms_config_fieldcat
               WITH KEY fieldname = ls_mod_cells-fieldname
               BINARY SEARCH.
          IF sy-subrc EQ 0 AND ms_config_fieldcat-change_evt EQ abap_true.
            lv_subrc_field = 0.
            CLEAR lv_form_name.
            CONCATENATE ms_header_config-alv_key '_' ls_mod_cells-fieldname '_CHANGED'
                     INTO lv_form_name.
            PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid)
                  USING er_data_changed
                        ls_mod_cells-row_id
                        ls_mod_cells-value
                  IF FOUND.
          ENDIF.
        ENDLOOP.
      CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.
*    IF lv_subrc_main EQ 0 OR lv_subrc_field EQ 0.
*      ls_stable-row = ls_stable-col = abap_true.
*      CALL METHOD me->refresh_table_display
*        EXPORTING
*          is_stable      = ls_stable
*          i_soft_refresh = abap_true
*        EXCEPTIONS
*          finished       = 1
*          OTHERS         = 2.
*    ENDIF.
  ENDMETHOD.


  METHOD handle_double_click.
    DATA lv_form_name TYPE string.
    DATA lv_str       TYPE string.

    CONCATENATE mv_alv_key '_DOUBLE_CLICK' INTO lv_form_name.

    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) USING e_row e_column es_row_no IF FOUND.
      CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.


  ENDMETHOD.


  METHOD handle_hotspot_click.
    DATA lv_form_name TYPE string.
    DATA lv_str       TYPE string.
    CONCATENATE mv_alv_key '_' e_column_id-fieldname '_CLICK' INTO lv_form_name.

    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) USING e_row_id e_column_id es_row_no IF FOUND.
      CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.

  ENDMETHOD.


  METHOD handle_onf4.
    DATA lv_value TYPE lvc_value.
    FIELD-SYMBOLS <lt_modi> TYPE lvc_t_modi.
    DATA : ls_modi TYPE lvc_s_modi.
    IF mt_f4_field[] IS INITIAL.
      MESSAGE 'No Fields Appended For F4' TYPE 'I' DISPLAY LIKE 'E'.
      EXIT.
    ENDIF.


    DATA : lv_form_name TYPE string,
           lv_str       TYPE string.

    CONCATENATE ms_header_config-alv_key '_' e_fieldname '_F4' INTO lv_form_name.

    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) USING es_row_no
                                                          IF FOUND.
      CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
        TRY.
            PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) USING  e_fieldname
                                                                          e_fieldvalue
                                                                          es_row_no
                                                                          er_event_data
                                                                          et_bad_cells
                                                                          e_display
                                                                          lv_value
                                                                   IF FOUND.
            IF lv_value IS NOT INITIAL.
              ASSIGN er_event_data->m_data->* TO <lt_modi>.
              ls_modi-row_id   = es_row_no-row_id.
              ls_modi-fieldname = e_fieldname.
              ls_modi-value = lv_value.
              APPEND ls_modi TO <lt_modi>.
            ENDIF.

          CATCH cx_sy_dyn_call_param_not_found cx_sy_dyn_call_param_missing.
            CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
            MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
        ENDTRY.
    ENDTRY.




    er_event_data->m_event_handled = 'X'.


  ENDMETHOD.


  METHOD handle_toolbar.
    DATA : lv_form_name TYPE string,
           lv_str       TYPE string,
           ls_toolbar   TYPE stb_button,
           ls_btnmnu    TYPE stb_btnmnu.

    DEFINE _set_toolbar.
      CLEAR ls_toolbar.
      MOVE &1 TO ls_toolbar-butn_type.
      MOVE &2 TO ls_toolbar-function.
      MOVE &3 TO ls_toolbar-icon.
      MOVE &4 TO ls_toolbar-quickinfo.
      MOVE &5 TO ls_toolbar-text.
      MOVE &6 TO ls_toolbar-disabled.
      APPEND ls_toolbar TO e_object->mt_toolbar.
    END-OF-DEFINITION.

    IF ms_header_config-zhelp EQ abap_true.
      _set_toolbar ' ' mc_ucomm-help icon_system_extended_help 'Help Guide' '' ' '.
      _set_toolbar '3' '' '' '' '' ' '.
    ENDIF.
    CASE mv_mode.
      WHEN mc_display_mode.
        IF ms_header_config-zrefresh EQ abap_true.
          _set_toolbar ' ' mc_ucomm-refresh icon_refresh 'Refresh' '' ' '.
        ENDIF.
        IF ms_header_config-zcreate EQ abap_true
           OR ms_header_config-zupdate EQ abap_true.
          _set_toolbar ' ' mc_ucomm-change icon_change 'Change' '' ' '.
          _set_toolbar '3' '' '' '' '' ' '.
        ENDIF.
        IF ms_header_config-zcreate EQ abap_true.
          _set_toolbar ' ' mc_create_mode icon_create 'Create' '' 'X'.
          _set_toolbar ' ' mc_ucomm-insert icon_insert_row 'Insert' '' 'X'.
        ENDIF.
        IF ms_header_config-zdelete EQ abap_true.
          IF ms_header_config-zcreate EQ abap_true
            OR ms_header_config-zupdate EQ abap_true.
            _set_toolbar ' ' mc_ucomm-delete icon_delete_row 'Delete' '' 'X'.
          ELSE.
            _set_toolbar ' ' mc_ucomm-delete icon_delete_row 'Delete' '' ' '.
          ENDIF.
        ENDIF.
      WHEN mc_change_mode.
        IF ms_header_config-zrefresh EQ abap_true.
          _set_toolbar ' ' mc_ucomm-refresh icon_refresh 'Refresh' '' 'X'.
        ENDIF.
        IF ms_header_config-zcreate EQ abap_true
           OR ms_header_config-zupdate EQ abap_true.
          _set_toolbar ' ' mc_ucomm-cancel icon_cancel 'Cancel' '' ' '.
          _set_toolbar '3' '' '' '' '' ' '.
        ENDIF.
        IF ms_header_config-zcreate EQ abap_true.
          _set_toolbar ' ' mc_create_mode icon_create 'Create' '' ' '.
          _set_toolbar ' ' mc_ucomm-insert icon_insert_row 'Insert' '' ' '.
        ENDIF.
        IF ms_header_config-zdelete EQ abap_true.
          _set_toolbar ' ' mc_ucomm-delete icon_delete_row 'Delete' '' ' '.
        ENDIF.
    ENDCASE.
    IF mv_mode NE mc_upload_mode.
      IF ms_header_config-zexcel EQ abap_true.
        _set_toolbar '3' '' '' '' '' ' '.
        _set_toolbar cntb_btype_dropdown mc_ucomm-xls icon_xls 'Excel' '' ''.

        IF mo_cl_menu_xls IS INITIAL.
          CREATE OBJECT mo_cl_menu_xls.
          CALL METHOD mo_cl_menu_xls->add_function
            EXPORTING
              fcode = mc_ucomm-upload
              text  = 'Upload'.
          CALL METHOD mo_cl_menu_xls->add_function
            EXPORTING
              fcode = mc_ucomm-download
              text  = 'Download'.

          CLEAR ls_btnmnu.
          ls_btnmnu-function = mc_ucomm-xls.
          ls_btnmnu-ctmenu   = mo_cl_menu_xls.
          APPEND ls_btnmnu TO e_object->mt_btnmnu.
        ENDIF.
      ENDIF.
    ENDIF.
    CONCATENATE mv_alv_key '_SET_TOOLBAR' INTO lv_form_name.

    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) USING e_interactive e_object IF FOUND.
      CATCH cx_sy_dyn_call_param_not_found.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.


  ENDMETHOD.


  METHOD handle_user_command.
    DATA : lv_form_name  TYPE string,
           lv_str        TYPE string,
           lv_help_tcode TYPE  tcode,
           lv_help_acode TYPE  char30.
    CONCATENATE mv_alv_key '_' e_ucomm '_CLICK' INTO lv_form_name.

    get_current_cell_col_id( IMPORTING col_id = ms_col_id ).
    get_current_cell_row_id( IMPORTING row_id = ms_row_id ).

    TRY.
        PERFORM (lv_form_name) IN PROGRAM (mv_callback_progid) IF FOUND.
        IF e_ucomm EQ mc_ucomm-help. "HELP GUIDE공통 호출

          lv_help_tcode = mv_progid.
          lv_help_acode = mv_alv_key.

          CALL FUNCTION 'ZCMA_WORK_HELP_DISPLAY'
            EXPORTING
              iv_tcode = lv_help_tcode
              iv_acode = lv_help_acode
            EXCEPTIONS
              no_data  = 1.
          IF sy-subrc NE 0.
            MESSAGE 'No Help Guide Found' TYPE 'I'.
          ENDIF.
        ENDIF.
      CATCH cx_sy_dyn_call_param_not_found.
        CONCATENATE lv_form_name ` subroutine parameters are not competable!!` INTO lv_str.
        MESSAGE lv_str TYPE 'I' DISPLAY LIKE 'E'.
    ENDTRY.



    set_current_cell_via_id( EXPORTING is_column_id = ms_col_id
                                       is_row_id = ms_row_id ).

  ENDMETHOD.


  METHOD insert_toolbar_button.
    DATA : ls_toolbar TYPE stb_button.
    CLEAR ls_toolbar.

    MOVE iv_butn_type TO ls_toolbar-butn_type.
    MOVE iv_function TO ls_toolbar-function.
    MOVE iv_icon TO ls_toolbar-icon.
    MOVE iv_quickinfo TO ls_toolbar-quickinfo.
    MOVE iv_text TO ls_toolbar-text.
    MOVE iv_disabled TO ls_toolbar-disabled.


    READ TABLE m_cl_toolbar->mt_toolbar TRANSPORTING NO FIELDS WITH KEY  function = iv_function .
    IF sy-subrc NE 0.
      INSERT ls_toolbar INTO m_cl_toolbar->mt_toolbar INDEX iv_index.
    ENDIF.

  ENDMETHOD.


  METHOD is_changing.
    rv_flag = mv_on_chainging_flag.
  ENDMETHOD.


  METHOD message.
    DATA : lv_str     TYPE string,
           lv_sub_str TYPE string.

    CASE iv_code.
      WHEN mc_msg-no_row_select.
        lv_str = TEXT-m01.
      WHEN mc_msg-no_change_data_found.
        lv_str = TEXT-m02.
      WHEN mc_msg-save_error.
        lv_str = TEXT-m03.
      WHEN mc_msg-save_success.
        IF iv_param1 IS NOT INITIAL.
          lv_str = TEXT-i01.
          lv_sub_str = iv_param1.
          CONDENSE lv_sub_str.
          REPLACE '&1' WITH lv_sub_str INTO lv_str.
        ENDIF.
        IF iv_param2 IS NOT INITIAL.
          lv_str = lv_str && TEXT-i02.
          lv_sub_str = iv_param2.
          CONDENSE lv_sub_str.
          REPLACE '&1' WITH lv_sub_str INTO lv_str.
        ENDIF.
        IF iv_param3 IS NOT INITIAL.
          lv_str = lv_str && TEXT-i03.
          lv_sub_str = iv_param3.
          CONDENSE lv_sub_str.
          REPLACE '&1' WITH lv_sub_str INTO lv_str.
        ENDIF.
        IF lv_str IS INITIAL.
          lv_str = TEXT-m04.
        ELSE.
          lv_str = lv_str.
        ENDIF.
      WHEN mc_msg-input_mandatory.
        lv_str = TEXT-m05.
    ENDCASE.

    rv_msg = lv_str.
  ENDMETHOD.


  METHOD message_popup.
    DATA: lo_table TYPE REF TO cl_salv_table.
    cl_salv_table=>factory( IMPORTING r_salv_table = lo_table
                            CHANGING  t_table = ct_msg ).
    lo_table->set_screen_popup( start_column = 1
                                end_column = 150
                                start_line = 1
                                end_line = 20 ).
    lo_table->display( ).
  ENDMETHOD.


  METHOD message_strip.
    DATA lv_str TYPE string.

    lv_str = message( EXPORTING iv_code = iv_code
                                iv_param1 = iv_param1
                                iv_param2 = iv_param2
                                iv_param3 = iv_param3
                                iv_param4 = iv_param4 ).
    IF iv_display IS INITIAL.
      MESSAGE lv_str TYPE iv_type.
    ELSE.
      MESSAGE lv_str TYPE iv_type DISPLAY LIKE iv_display.
    ENDIF.

  ENDMETHOD.


  METHOD refresh.
    DATA : ls_stable  TYPE lvc_s_stbl.
    IF iv_hard_refresh EQ abap_true.
      refresh_table_display( ).
    ELSE.
      ls_stable-col = ls_stable-row = abap_true.
      refresh_table_display( EXPORTING is_stable = ls_stable
                                       i_soft_refresh = abap_true ).
    ENDIF.
  ENDMETHOD.


  METHOD rollback_fail.
    MESSAGE 'Process Failed!!' TYPE 'I' DISPLAY LIKE 'E'.
    ROLLBACK WORK.
  ENDMETHOD.


  METHOD set_celltab_style.
    CLEAR ct_celltab.
*      IF ms_header_config-zcreate EQ abap_true
    CASE iv_mode.
      WHEN mc_change_mode.
        IF ms_header_config-zupdate EQ abap_false.
          EXIT.
        ENDIF.
        LOOP AT mt_config_fieldcat ASSIGNING FIELD-SYMBOL(<ls_fieldcat>) WHERE tech EQ abap_false.
          IF <ls_fieldcat>-chan_edit EQ abap_true.
            INSERT VALUE #( fieldname = <ls_fieldcat>-fieldname
                            style = cl_gui_alv_grid=>mc_style_enabled
                          ) INTO TABLE ct_celltab.
          ELSE.
            INSERT VALUE #( fieldname = <ls_fieldcat>-fieldname
                            style = cl_gui_alv_grid=>mc_style_disabled
                          ) INTO TABLE ct_celltab.
          ENDIF.
        ENDLOOP.
      WHEN mc_create_mode.
        LOOP AT mt_config_fieldcat ASSIGNING <ls_fieldcat> WHERE tech EQ abap_false.
          IF <ls_fieldcat>-crea_edit EQ abap_true.
            INSERT VALUE #( fieldname = <ls_fieldcat>-fieldname
                            style = cl_gui_alv_grid=>mc_style_enabled
                          ) INTO TABLE ct_celltab.
          ELSE.
            INSERT VALUE #( fieldname = <ls_fieldcat>-fieldname
                            style = cl_gui_alv_grid=>mc_style_disabled
                          ) INTO TABLE ct_celltab.
          ENDIF.
        ENDLOOP.
    ENDCASE.
  ENDMETHOD.


  METHOD set_changing_flag.
    mv_on_chainging_flag = iv_flag.
  ENDMETHOD.


  METHOD set_default_exclude_toolbar.
    DATA : lv_ui_func TYPE ui_func.

    DEFINE _set_toolbar_exclude.
      CLEAR : lv_ui_func.
      lv_ui_func = &1.
      APPEND lv_ui_func TO mt_excluding_toolbar.
    END-OF-DEFINITION.

    CLEAR mt_excluding_toolbar.

*    CASE mv_mode.
*      WHEN mc_display_mode.
    _set_toolbar_exclude :
      mc_fc_loc_undo,
      mc_fc_auf,
*      mc_fc_average,
      mc_fc_back_classic,
      mc_fc_call_abc,
      mc_fc_call_chain,
      mc_fc_call_crbatch,
      mc_fc_call_crweb,

*      mc_fc_call_lineitems,
*      mc_fc_call_master_data,
*      mc_fc_call_more,
*      mc_fc_call_report,
*      mc_fc_call_xint,
*      mc_fc_call_xxl,
*      mc_fc_col_invisible,
*      mc_fc_col_optimize,

*      mc_fc_current_variant,
*      mc_fc_load_variant,
*      mc_fc_maintain_variant,
*      mc_fc_save_variant,
*      mc_fc_sum,

      mc_fc_data_save,
*      mc_fc_delete_filter,
      mc_fc_deselect_all,
*      mc_fc_detail,
      mc_fc_expcrdata,
      mc_fc_expcrdesig,
      mc_fc_expcrtempl,
      mc_fc_expmdb,
      mc_fc_extend,
      mc_fc_f4,
      mc_fc_fix_columns,
      mc_fc_graph,
      mc_fc_help,
      mc_fc_info,
      mc_fc_loc_copy,
      mc_fc_html,
      mc_fc_loc_copy_row,
      mc_fc_loc_cut,
      mc_fc_loc_delete_row,
      mc_fc_loc_insert_row,
      mc_fc_loc_move_row,
      mc_fc_loc_append_row,
      mc_fc_loc_paste,
      mc_fc_loc_paste_new_row,
      mc_fc_maximum,
      mc_fc_minimum,
      mc_fc_print,
      mc_fc_print_back,
      mc_fc_print_prev,
      mc_fc_refresh,
      mc_fc_reprep,
      mc_fc_select_all,
      mc_fc_send,
      mc_fc_separator,
      mc_fc_pc_file,
*      mc_mb_export,
*      mc_fc_subtot,
      mc_fc_to_office,
      mc_fc_to_rep_tree,
      mc_fc_unfix_columns,
      mc_fc_views,
      mc_fc_view_crystal,
      mc_fc_view_excel,
      mc_fc_view_grid,
      mc_fc_word_processor,
      mc_fc_url_copy_to_clipboard,
      mc_fc_check.
*      WHEN OTHERS.
**        CLEAR mt_toolbar.
*    ENDCASE.

  ENDMETHOD.


  METHOD set_default_fieldcat.
  ENDMETHOD.


  METHOD set_events.
    SET HANDLER handle_toolbar FOR me.
    SET HANDLER handle_user_command FOR me.
    IF ms_header_config-after_refresh EQ abap_true.
      SET HANDLER handle_after_refresh FOR me.
    ENDIF.
    IF ms_header_config-db_click EQ abap_true.
      SET HANDLER handle_double_click FOR me.
    ENDIF.

    IF mv_is_field_button_exists = abap_true.
      SET HANDLER handle_button_click FOR me.
    ENDIF.
    IF mv_is_hot_spot_exists = abap_true.
      SET HANDLER handle_hotspot_click FOR me.
    ENDIF.

    IF ms_header_config-change_evt EQ abap_true.
      mv_is_set_change_evt = abap_true.
    ENDIF.

    IF mv_is_set_change_evt = abap_true.
      SET HANDLER handle_data_changed FOR me.

      CALL METHOD register_edit_event
        EXPORTING
          i_event_id = cl_gui_alv_grid=>mc_evt_modified.
      CALL METHOD register_edit_event
        EXPORTING
          i_event_id = cl_gui_alv_grid=>mc_evt_enter.
    ENDIF.

    IF mv_is_f4_exists = abap_true.
      register_f4_for_fields( EXPORTING it_f4 = mt_f4_field[] ).
      SET HANDLER handle_onf4 FOR me.
    ENDIF.
  ENDMETHOD.


  METHOD set_fieldcat.
    DATA : ls_fcat        TYPE lvc_s_fcat,
           ls_fcat_origin TYPE lvc_s_fcat,
           lv_tabix       TYPE sy-tabix.
    DATA lt_fieldcat_frontend TYPE lvc_t_fcat.
    DATA : ls_config_fcat      TYPE ts_fcat_config.

    CLEAR mt_fieldcat.

*    get_frontend_fieldcatalog( IMPORTING et_fieldcatalog = lt_fieldcat_frontend ).
    CLEAR mt_f4_field.
    LOOP AT mt_config_fieldcat INTO ls_config_fcat.

      CLEAR ls_fcat.
      MOVE-CORRESPONDING ls_config_fcat TO ls_fcat.
      ls_fcat-key = ls_config_fcat-zkey.

      CASE mv_mode.
        WHEN mc_display_mode. CLEAR ls_fcat-edit.
        WHEN mc_create_mode. ls_fcat-edit = ls_config_fcat-crea_edit.
        WHEN mc_change_mode. ls_fcat-edit = ls_config_fcat-chan_edit.
        WHEN mc_upload_mode. ls_fcat-edit = ls_config_fcat-upld_edit.
      ENDCASE.


      IF ls_config_fcat-button EQ abap_true.
        ls_fcat-style = cl_gui_alv_grid=>mc_style_button.
      ENDIF.

      IF ls_fcat-currency = 'T001'.
        ls_fcat-currency = mv_bukrs_waers.
      ENDIF.

      READ TABLE mt_fieldcat TRANSPORTING NO FIELDS WITH KEY fieldname = ls_config_fcat-fieldname.
      lv_tabix = sy-tabix.
      IF sy-subrc EQ 0.
        MODIFY mt_fieldcat FROM ls_fcat INDEX lv_tabix.
      ELSE.
        APPEND ls_fcat TO mt_fieldcat.
      ENDIF.

      IF ls_config_fcat-button = abap_true.
        mv_is_field_button_exists = abap_true.
      ENDIF.
      IF ls_config_fcat-hotspot = abap_true.
        mv_is_hot_spot_exists = abap_true.
      ENDIF.
      IF ls_config_fcat-change_evt = abap_true.
        mv_is_set_change_evt = abap_true.
      ENDIF.

      IF ls_config_fcat-f4availabl = abap_true.
        mv_is_f4_exists = abap_true.
        ms_f4_field-fieldname  = ls_config_fcat-fieldname.
        ms_f4_field-register   = abap_true.
        ms_f4_field-getbefore  = space.
        ms_f4_field-chngeafter = abap_true.
        APPEND ms_f4_field TO mt_f4_field.
      ENDIF.

      CLEAR : ls_fcat, ls_config_fcat.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
